<?php
include_once("../classes/manipuladados.php");
?>
<html>

<body>
    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-9 mx-auto">
                <div class="card border-0 shadow rounded-3 my-5">
                    <div class="card-body p-4 p-sm-5">
                        <h3 class="card-title text-center">Cadastrar Eventos</h3>
                        <div class="cont">


                            <form method="post" enctype="multipart/form-data" action="controller/cadastrarEvento.php">
                                <div class="form-floating mb-3">

                                    <p><label for="titulo">Informe o titulo do Evento</label></p>
                                    <p><input type="text" name="txtDescricao" /></p>

                                    <p><label for="titulo">Informe a descrição do Evento</label></p>
                                    <p><input type="text" name="txtDescricao" /></p>

                                    <p><label>Informe a data do Evento</label></p>
                                    <p>
                                        <input type="date" name="txtValor" />
                                    </p>
                                    </p>
                                    <p><label>Informe o horário de início</label></p>
                                    <p>
                                        <input type="time" name="txtValor" />
                                    </p>
                                    </p>
                                    <p><label>Informe o horário de fim</label></p>
                                    <p>
                                        <input type="time" name="txtValor" />
                                    </p>
                                    </p>

                                    <p><label>Informe o número de vagas</label></p>
                                    <p>
                                        <input type="number" name="txtValor" />
                                    </p>
                                    </p>
                                    <p><label>Informe a quantidade de horas</label></p>
                                    <p>
                                        <input type="number" name="txtValor" />
                                    </p>
                                    </p>
                                        <input class="btn btn-dark" type="submit" value="Enviar" />
                                        <input class="btn btn-dark" type="reset" value="Limpar" />
                                    </p>
                                    </br>
                            </form>



</body>

</html>