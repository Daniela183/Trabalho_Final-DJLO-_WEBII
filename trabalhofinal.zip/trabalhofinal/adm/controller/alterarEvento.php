<?php

include_once("../../classes/manipuladados.php");

function converte($Strings)
{
    return iconv("UTF-8", "ISO8859-1", $Strings);
}

$id = $_POST['txtid'];
$nome = $_POST['txtnome'];
$tipo = $_POST['numtipo'];
$preco = $_POST["txtpreco"];

$nomearquivosalvo = converte($_FILES['arquivo']['name']);
$urlbanco = "img/" . $nomearquivosalvo;
$urllocalsalvo = "../../img/" . $nomearquivosalvo;
move_uploaded_file($_FILES['arquivo']['tmp_name'], $urllocalsalvo);



if ($tipo == 1){
    echo "Nome: ".$nome. "<br/> Tipo: Peça <br/>Preço: ".$preco. "<br/>URL:" .$urlbanco;

}else{
    echo "Nome: ".$nome. "<br/> Tipo: Caminhão <br/>Preço: ".$preco. "<br/>URL:" .$urlbanco;
}

$alterar = new manipuladados();
$alterar->setTable("tb_produto");
$alterar->setFields("nome= '$nome', tipo='$tipo', preco='$preco', url='$urlbanco'");
$alterar->setFieldId("id");
$alterar->setValueId($id);
$alterar->update();

echo '<script> alert("' . $alterar->getStatus() . '");</script>';
echo "<script> location = '../principal.php';</script>";
