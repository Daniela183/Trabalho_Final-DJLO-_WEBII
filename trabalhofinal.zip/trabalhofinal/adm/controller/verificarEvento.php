<?php
include_once("../../classes/manipuladados.php");

$op = $_POST["botao"];
$id = $_POST["id"];
$nome = $_POST["txtnome"];
$tipo = $_POST["numtipo"];
$preco = $_POST["txtpreco"];
$url = $_POST["url"];


switch ($op) {
    case "editar":
        echo 
        '<h1>Tela de Alterar Produtos</h1>
    <form action="alterarproduto.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="txtid" id="" value="' . $id . '"><br><br>
        <p><label for="">Digite o nome do produto:</label></p>
        <input type="text" name="txtnome" id="" value="' . $nome . '"><br><br>
        <p><label for="">Digite o tipo do produto:</label></p>
        <textarea name="numtipo" rows="10" cols="40">' . $tipo . '</textarea> <br><br>
        <p><label for="">Digite o preço:</label></p>
        <input type="text" name="txtpreco" id="" value="' . $preco . '"><br><br>
        <p><label for="">Faça o upload da imagem:</label></p>

        <input type="file" name="arquivo"> <br><br>

        <input type="submit" value="Alterar" class="btn btn-lg btn-success form-group">
        <input type="reset" value="Limpar" class="btn btn-lg btn-success">
    </form>';
        break;


    case "excluir":
        $remove = new manipuladados();
        $remove->setTable("tb_produto");
        $remove->setFieldId("id");
        $remove->setvalueId("$id");
        $remove->delete();
        echo '<script> alert("O arquivo foi removido com sucesso");</script>';
        echo "<script> location = '../principal.php';</script>";


        break;
    default:
        exit("NÂO CONSEGUIU HEHEHEH!");

        break;
}
