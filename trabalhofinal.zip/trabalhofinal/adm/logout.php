<?php
setcookie("nome_usuario");
setcookie("senha_usuario");
header("location: index.php")
?>