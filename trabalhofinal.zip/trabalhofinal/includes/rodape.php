<?php
?>
  <!-- Grid container -->
  <div class="container p-4 mt-3 nb ">
    <!--Grid row-->
    <div class="row">
      <!--Grid column-->
      <footer class="text-center text-white">
      <!-- Grid container -->
      <div class="container p-4"></div>
      <!-- Grid container -->

      <!-- Copyright -->
      <div class="text-center p-3">
        <h5 style="font-weight: bold;">Instituto Federal de Educação, Ciência e Tecnologia de Goiás</h5>
        <p>Av. Assis Chateaubriand, nº 1.658, Setor Oeste,  
          <br>Goiânia, Goiás, Brasil,
          <br>CEP: 74130-012</p>
        © 2022: (DJLO)
      </div>
      <!-- Copyright -->
    </footer>
      <!--Grid column-->

      
      <!--Grid column-->
    </div>
    <!--Grid row-->
  </div>
  <!-- Grid container -->

  <script src='js/bootstrap.bundle.js'></script>

    
</body>
</html>