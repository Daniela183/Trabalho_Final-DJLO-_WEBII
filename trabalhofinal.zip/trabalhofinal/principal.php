<?php
?>
<!DOCTYPE html>
<html>



<body>

  <section class="container shadow p-3 mb-5 bg-body rounded" style="margin-top: 8.6%;">
    <center>
      <h1 class="">SEMANA DO MEIO AMBIENTE</h1>
    </center>
    <br><br>
    <div class="row justify-content-between">

      <article class=" pb-2 col-lg-12 col-md-6 col-sm-12 ">
        <div class=" card text-center">

          <div class="card-body">
            <h5 class="card-title">Ciclo de palestras sobre pesquisas em andamento - Mesa-redonda 2</h5>
            <p class="card-text">Câmpus Senador Canedo
              Instituto Federal de Educação, Ciência e Tecnologia de Goiás.</p>
            
          </div>
          <div class=" card-footer text-muted">
            Inscrições 14/06/2022 à 04/11/2022
          </div>
        </div>

      </article>
      <article class=" pb-2 col-lg-12 col-md-6 col-sm-12 ">
        <div class="card text-center">

          <div class="card-body">
            <h5 class="card-title">Ciclo de palestras sobre pesquisas em andamento - Mesa-redonda 2</h5>
            <p class="card-text">Câmpus Senador Canedo
              Instituto Federal de Educação, Ciência e Tecnologia de Goiás.</p>
            
          </div>
          <div class="card-footer text-muted">
            Inscrições 14/06/2022 à 04/11/2022
          </div>
        </div>
      </article>
      <article class=" pb-2 col-lg-12 col-md-6 col-sm-12 ">
        <div class="card text-center">

          <div class="card-body">
            <h5 class="card-title">Ciclo de palestras sobre pesquisas em andamento - Mesa-redonda 2</h5>
            <p class="card-text">Câmpus Senador Canedo
              Instituto Federal de Educação, Ciência e Tecnologia de Goiás.</p>
          </div>
          <div class="card-footer text-muted">
            Inscrições 14/06/2022 à 04/11/2022
          </div>
      </article>
    </div>



  </section>

</body>

</html>