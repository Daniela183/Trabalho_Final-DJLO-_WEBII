<?php
require('fpdf.php');
include_once('../classes/manipuladados.php');
function convert($String){
    return iconv("UTF-8","ISO8859-1", $String);

}
$pdf = new FPDF();
$busca = new manipuladados();
$busca->setTable("tb_produto");
$noticias = $busca->getAllDataTable();

$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
$pdf->Cell(40,10,'Todos os Produtos');
$pdf->Ln(10);
foreach ($noticias as $dados) {




$pdf->Ln(1);

$pdf->MultiCell(420,10,$dados["nome"].' -----------------------------------------------------------------------------> '.$dados["preco"]);


}
$pdf->Ln(10);
$pdf->Cell(40,10,'Total  dos '.convert('Preços'));
$pdf->Ln(10);
$i = 0;
foreach ($noticias as $dados) {
$pdf->Ln(1);

$i = $i + (int)$dados["preco"];


}
$pdf->SetX(170);
$pdf->MultiCell(40,10, $i);
//$pdf->Image('../'.$dados["preco"], 0,0,$pdf->GetPageWidth(), $pdf->GetPageHeight());
$pdf->Output('relatorio.pdf','I');
?>